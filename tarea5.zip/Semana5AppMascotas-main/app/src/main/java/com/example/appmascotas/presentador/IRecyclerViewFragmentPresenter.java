package com.example.appmascotas.presentador;

public interface IRecyclerViewFragmentPresenter {

    public void obtenerMascotasBaseDatos();

    public void mostrarContactosRV();
}
